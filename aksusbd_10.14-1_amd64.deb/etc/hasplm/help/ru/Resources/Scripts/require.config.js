require.config({
    urlArgs: 't=638143163222016605'
});